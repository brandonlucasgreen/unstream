var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/embed-bandcamp.ts
var embed_bandcamp_exports = {};
__export(embed_bandcamp_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(embed_bandcamp_exports);
async function fetchWithTimeout(url, options = {}, timeoutMs = 5e3) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    return response;
  } finally {
    clearTimeout(timeoutId);
  }
}
async function getBandcampEmbed(url) {
  try {
    const isAlbumUrl = url.includes("/album/");
    const isTrackUrl = url.includes("/track/");
    const response = await fetchWithTimeout(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
      }
    }, 5e3);
    if (!response.ok) return null;
    const html = await response.text();
    if (isAlbumUrl || isTrackUrl) {
      const itemType2 = isAlbumUrl ? "album" : "track";
      const directMatch = html.match(new RegExp(`${itemType2}=(\\d+)`));
      const jsonMatch = html.match(new RegExp(`"${itemType2}_id"\\s*:\\s*(\\d+)`));
      const currentIdMatch = html.match(/"current"\s*:\s*\{[^}]*"id"\s*:\s*(\d+)/);
      const idMatch2 = directMatch || jsonMatch || currentIdMatch;
      if (!idMatch2) return null;
      const itemId2 = idMatch2[1];
      const titleMatch2 = html.match(/<title>([^<]+)<\/title>/);
      const title2 = titleMatch2?.[1]?.split("|")[0]?.trim() || "Music";
      return {
        embedUrl: `https://bandcamp.com/EmbeddedPlayer/${itemType2}=${itemId2}/size=small/bgcol=ffffff/linkcol=0687f5/transparent=true/`,
        title: title2
      };
    }
    const albumMatch = html.match(/href="(\/album\/[^"]+)"/);
    const trackMatch = html.match(/href="(\/track\/[^"]+)"/);
    let itemPath = albumMatch?.[1] || trackMatch?.[1];
    const itemType = albumMatch ? "album" : "track";
    if (!itemPath) {
      const trackIdMatch = html.match(/data-item-id="track-(\d+)"/);
      if (trackIdMatch) {
        const trackId = trackIdMatch[1];
        return {
          embedUrl: `https://bandcamp.com/EmbeddedPlayer/track=${trackId}/size=small/bgcol=ffffff/linkcol=0687f5/transparent=true/`,
          title: "Track"
        };
      }
      return null;
    }
    const baseUrl = url.replace(/\/$/, "").replace(/\/music$/, "");
    const itemUrl = baseUrl + itemPath;
    const itemResponse = await fetchWithTimeout(itemUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
      }
    }, 5e3);
    if (!itemResponse.ok) return null;
    const itemHtml = await itemResponse.text();
    const idMatch = itemHtml.match(new RegExp(`${itemType}=(\\d+)`));
    if (!idMatch) return null;
    const itemId = idMatch[1];
    const titleMatch = itemHtml.match(/<title>([^<]+)<\/title>/);
    const title = titleMatch?.[1]?.split("|")[0]?.trim() || "Music";
    return {
      embedUrl: `https://bandcamp.com/EmbeddedPlayer/${itemType}=${itemId}/size=small/bgcol=ffffff/linkcol=0687f5/transparent=true/`,
      title
    };
  } catch (error) {
    const err = error;
    console.error("Bandcamp embed error:", err.message);
    return null;
  }
}
async function handler(event) {
  const url = event.queryStringParameters?.url;
  if (!url) {
    return {
      statusCode: 400,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: "URL parameter is required" })
    };
  }
  try {
    const embedData = await getBandcampEmbed(url);
    if (embedData) {
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Cache-Control": "s-maxage=3600, stale-while-revalidate"
        },
        body: JSON.stringify(embedData)
      };
    } else {
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({ error: "Could not find embeddable content" })
      };
    }
  } catch (error) {
    console.error("Embed error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: "Failed to fetch embed data" })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
