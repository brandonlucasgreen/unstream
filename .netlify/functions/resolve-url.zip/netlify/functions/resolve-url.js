var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/resolve-url.ts
var resolve_url_exports = {};
__export(resolve_url_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(resolve_url_exports);
async function fetchWithTimeout(url, options = {}, timeoutMs = 5e3) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    return response;
  } finally {
    clearTimeout(timeoutId);
  }
}
async function resolveStreamingUrl(url) {
  try {
    if (url.startsWith("spotify:")) {
      const parts = url.split(":");
      if (parts.length >= 3) {
        url = `https://open.spotify.com/${parts[1]}/${parts[2]}`;
      }
    }
    const spotifyMatch = url.match(/open\.spotify\.com\/(artist|album|track)\/([a-zA-Z0-9]+)/);
    if (spotifyMatch) {
      const response = await fetchWithTimeout(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
        }
      }, 5e3);
      if (!response.ok) return null;
      const html = await response.text();
      const type = spotifyMatch[1];
      if (type === "artist") {
        const titleMatch = html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i) || html.match(/<meta\s+content="([^"]+)"\s+property="og:title"/i);
        if (titleMatch) {
          return { artistName: titleMatch[1], source: "spotify" };
        }
      } else {
        const descMatch = html.match(/<meta\s+property="og:description"\s+content="[^"]*(?:by|from)\s+([^"·]+)/i) || html.match(/<meta\s+content="[^"]*(?:by|from)\s+([^"·]+)"\s+property="og:description"/i);
        if (descMatch) {
          return { artistName: descMatch[1].trim(), source: "spotify" };
        }
        const artistLinkMatch = html.match(/href="\/artist\/[^"]+">([^<]+)<\/a>/);
        if (artistLinkMatch) {
          return { artistName: artistLinkMatch[1].trim(), source: "spotify" };
        }
        const titleMatch = html.match(/<title>([^<]+)<\/title>/);
        if (titleMatch) {
          const parts = titleMatch[1].split(/\s*[-–—]\s*/);
          if (parts.length >= 2) {
            let artist = parts[1].replace(/\s*[-–—]\s*Spotify.*$/i, "").trim();
            if (artist && artist.toLowerCase() !== "spotify") {
              return { artistName: artist, source: "spotify" };
            }
          }
        }
      }
      return null;
    }
    const appleMatch = url.match(/music\.apple\.com\/[a-z]{2}\/(artist|album|song)\/([^/]+)\/(\d+)/);
    if (appleMatch) {
      const response = await fetchWithTimeout(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
        }
      }, 5e3);
      if (!response.ok) return null;
      const html = await response.text();
      const type = appleMatch[1];
      const cleanAppleMusicSuffix = (name) => {
        return name.replace(/\s+on\s+Apple\s*Music.*$/i, "").replace(/\s*[-–—]\s*Apple\s*Music.*$/i, "").replace(/\s*\|\s*Apple\s*Music.*$/i, "").trim();
      };
      if (type === "artist") {
        const titleMatch = html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i) || html.match(/<meta\s+content="([^"]+)"\s+property="og:title"/i);
        if (titleMatch) {
          const artistName = cleanAppleMusicSuffix(titleMatch[1]);
          return { artistName, source: "apple" };
        }
      } else {
        const titleMatch = html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i) || html.match(/<meta\s+content="([^"]+)"\s+property="og:title"/i);
        if (titleMatch) {
          const cleanedTitle = cleanAppleMusicSuffix(titleMatch[1]);
          const byMatch = cleanedTitle.match(/^.+?\s+by\s+(.+)$/i);
          if (byMatch) {
            const artistName = cleanAppleMusicSuffix(byMatch[1]);
            return { artistName, source: "apple" };
          }
        }
        const artistMeta = html.match(/<meta\s+name="twitter:audio:artist_name"\s+content="([^"]+)"/i) || html.match(/<meta\s+content="([^"]+)"\s+name="twitter:audio:artist_name"/i);
        if (artistMeta) {
          return { artistName: cleanAppleMusicSuffix(artistMeta[1]), source: "apple" };
        }
      }
      return null;
    }
    return null;
  } catch (error) {
    const err = error;
    console.error("URL resolution error:", err.message);
    return null;
  }
}
async function handler(event) {
  const url = event.queryStringParameters?.url;
  if (!url) {
    return {
      statusCode: 400,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: "URL parameter is required" })
    };
  }
  try {
    const result = await resolveStreamingUrl(url);
    if (result) {
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Cache-Control": "s-maxage=86400, stale-while-revalidate"
        },
        body: JSON.stringify(result)
      };
    } else {
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({ error: "Could not resolve artist from URL" })
      };
    }
  } catch (error) {
    console.error("Resolve error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: "Failed to resolve URL" })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
