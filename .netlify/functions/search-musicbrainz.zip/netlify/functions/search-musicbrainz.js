var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/search-musicbrainz.ts
var search_musicbrainz_exports = {};
__export(search_musicbrainz_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(search_musicbrainz_exports);
function parseSocialUrl(url) {
  const urlLower = url.toLowerCase();
  if (urlLower.includes("instagram.com")) {
    return { platform: "instagram", url };
  }
  if (urlLower.includes("facebook.com")) {
    return { platform: "facebook", url };
  }
  if (urlLower.includes("tiktok.com")) {
    return { platform: "tiktok", url };
  }
  if (urlLower.includes("youtube.com") || urlLower.includes("youtu.be")) {
    return { platform: "youtube", url };
  }
  if (urlLower.includes("threads.net") || urlLower.includes("threads.com")) {
    return { platform: "threads", url };
  }
  if (urlLower.includes("bsky.app") || urlLower.includes("bluesky")) {
    return { platform: "bluesky", url };
  }
  if (urlLower.includes("twitter.com") || urlLower.includes("x.com")) {
    return { platform: "twitter", url };
  }
  return null;
}
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
function extractDiscogsArtistId(discogsUrl) {
  const match = discogsUrl.match(/\/artist\/(\d+)/);
  return match ? match[1] : null;
}
async function fetchDiscogsSocialLinks(discogsUrl) {
  const socialLinks = [];
  const artistId = extractDiscogsArtistId(discogsUrl);
  if (!artistId) return socialLinks;
  try {
    const response = await globalThis.fetch(`https://api.discogs.com/artists/${artistId}`, {
      headers: {
        "User-Agent": "Unstream/1.0 (https://unstream.stream - ethical music finder)"
      }
    });
    if (!response.ok) {
      console.log("Discogs API failed:", response.status);
      return socialLinks;
    }
    const data = await response.json();
    const urls = data.urls || [];
    for (const url of urls) {
      const socialLink = parseSocialUrl(url);
      if (socialLink) {
        socialLinks.push(socialLink);
      }
    }
  } catch (error) {
    const err = error;
    console.error("Discogs fetch error:", err.message);
  }
  return socialLinks;
}
async function fetchOfficialSiteSocialLinks(officialUrl) {
  const socialLinks = [];
  const seenPlatforms = /* @__PURE__ */ new Set();
  try {
    const response = await globalThis.fetch(officialUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
      },
      signal: AbortSignal.timeout(5e3)
    });
    if (!response.ok) {
      console.log("Official site fetch failed:", response.status);
      return socialLinks;
    }
    const html = await response.text();
    const hrefMatches = html.matchAll(/href=["']([^"']+)["']/gi);
    for (const match of hrefMatches) {
      const url = match[1];
      if (!url.startsWith("http")) continue;
      const socialLink = parseSocialUrl(url);
      if (socialLink && !seenPlatforms.has(socialLink.platform)) {
        seenPlatforms.add(socialLink.platform);
        socialLinks.push(socialLink);
      }
    }
  } catch (error) {
    const err = error;
    console.error("Official site fetch error:", err.message);
  }
  return socialLinks;
}
function mergeSocialLinks(...linkArrays) {
  const seenPlatforms = /* @__PURE__ */ new Set();
  const merged = [];
  for (const links of linkArrays) {
    for (const link of links) {
      if (!seenPlatforms.has(link.platform)) {
        seenPlatforms.add(link.platform);
        merged.push(link);
      }
    }
  }
  return merged;
}
async function searchMusicBrainz(query) {
  const emptyResult = {
    query,
    artistName: null,
    officialUrl: null,
    discogsUrl: null,
    hasPre2005Release: false,
    socialLinks: []
  };
  try {
    const searchUrl = `https://musicbrainz.org/ws/2/artist/?query=artist:${encodeURIComponent(query)}&fmt=json&limit=1`;
    const response = await globalThis.fetch(searchUrl, {
      headers: {
        "User-Agent": "Unstream/1.0 (https://github.com/unstream - ethical music finder)"
      }
    });
    if (!response.ok) {
      console.log("MusicBrainz artist search failed:", response.status);
      return emptyResult;
    }
    const data = await response.json();
    const artists = data.artists || [];
    if (artists.length === 0) return emptyResult;
    const artist = artists[0];
    if (artist.score < 95) return emptyResult;
    await delay(1100);
    const artistUrl = `https://musicbrainz.org/ws/2/artist/${artist.id}?inc=url-rels&fmt=json`;
    const artistResponse = await globalThis.fetch(artistUrl, {
      headers: {
        "User-Agent": "Unstream/1.0 (https://github.com/unstream - ethical music finder)"
      }
    });
    let officialUrl = null;
    let discogsUrl = null;
    const socialLinks = [];
    const seenPlatforms = /* @__PURE__ */ new Set();
    if (artistResponse.ok) {
      const artistData = await artistResponse.json();
      const relations = artistData.relations || [];
      for (const rel of relations) {
        if (rel.type === "official homepage" && rel.url?.resource) {
          officialUrl = rel.url.resource;
          break;
        }
      }
      for (const rel of relations) {
        if (rel.type === "discogs" && rel.url?.resource) {
          discogsUrl = rel.url.resource;
          break;
        }
      }
      for (const rel of relations) {
        if ((rel.type === "social network" || rel.type === "youtube") && rel.url?.resource) {
          const socialLink = parseSocialUrl(rel.url.resource);
          if (socialLink && !seenPlatforms.has(socialLink.platform)) {
            seenPlatforms.add(socialLink.platform);
            socialLinks.push(socialLink);
          }
        }
      }
    }
    await delay(1100);
    const releasesUrl = `https://musicbrainz.org/ws/2/release-group/?artist=${artist.id}&fmt=json&limit=20`;
    const releasesResponse = await globalThis.fetch(releasesUrl, {
      headers: {
        "User-Agent": "Unstream/1.0 (https://github.com/unstream - ethical music finder)"
      }
    });
    let hasPre2005Release = false;
    if (releasesResponse.ok) {
      const releasesData = await releasesResponse.json();
      const releaseGroups = releasesData["release-groups"] || [];
      for (const rg of releaseGroups) {
        const firstReleaseDate = rg["first-release-date"];
        if (firstReleaseDate) {
          const year = parseInt(firstReleaseDate.substring(0, 4), 10);
          if (year < 2005) {
            hasPre2005Release = true;
            break;
          }
        }
      }
    }
    const [discogsSocialLinks, officialSiteSocialLinks] = await Promise.all([
      discogsUrl ? fetchDiscogsSocialLinks(discogsUrl) : Promise.resolve([]),
      officialUrl ? fetchOfficialSiteSocialLinks(officialUrl) : Promise.resolve([])
    ]);
    const allSocialLinks = mergeSocialLinks(socialLinks, discogsSocialLinks, officialSiteSocialLinks);
    return {
      query,
      artistName: artist.name,
      officialUrl,
      discogsUrl,
      hasPre2005Release,
      socialLinks: allSocialLinks
    };
  } catch (error) {
    const err = error;
    console.error("MusicBrainz search error:", err.name, err.message);
    return emptyResult;
  }
}
async function handler(event) {
  const query = event.queryStringParameters?.query;
  if (!query) {
    return {
      statusCode: 400,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: "Query parameter is required" })
    };
  }
  try {
    const result = await searchMusicBrainz(query);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "s-maxage=300, stale-while-revalidate"
      },
      body: JSON.stringify(result)
    };
  } catch (error) {
    console.error("MusicBrainz endpoint error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        query,
        artistName: null,
        officialUrl: null,
        discogsUrl: null,
        hasPre2005Release: false,
        socialLinks: []
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
