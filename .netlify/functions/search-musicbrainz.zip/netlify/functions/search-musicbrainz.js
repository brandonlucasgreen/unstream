var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/search-musicbrainz.ts
var search_musicbrainz_exports = {};
__export(search_musicbrainz_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(search_musicbrainz_exports);
var KNOWN_MASTODON_INSTANCES = [
  "mastodon.social",
  "mastodon.online",
  "mastodon.art",
  "mastodon.world",
  "mstdn.social",
  "mstdn.jp",
  "fosstodon.org",
  "hachyderm.io",
  "plush.city",
  "tech.lgbt",
  "wandering.shop",
  "musician.social",
  "metalhead.club",
  "social.coop",
  "aus.social",
  "infosec.exchange",
  "sfba.social",
  "universeodon.com",
  "c.im",
  "toot.cafe"
];
function isMastodonInstance(urlLower) {
  return KNOWN_MASTODON_INSTANCES.some((instance) => urlLower.includes(instance));
}
function convertMastodonHandleToUrl(handle) {
  const match = handle.match(/@?([^@]+)@(.+)/);
  if (match) {
    return `https://${match[2]}/@${match[1]}`;
  }
  return null;
}
function parseSocialUrl(url) {
  const urlLower = url.toLowerCase();
  if (urlLower.includes("instagram.com")) {
    return { platform: "instagram", url };
  }
  if (urlLower.includes("facebook.com")) {
    return { platform: "facebook", url };
  }
  if (urlLower.includes("tiktok.com")) {
    return { platform: "tiktok", url };
  }
  if (urlLower.includes("youtube.com") || urlLower.includes("youtu.be")) {
    return { platform: "youtube", url };
  }
  if (urlLower.includes("threads.net") || urlLower.includes("threads.com")) {
    return { platform: "threads", url };
  }
  if (urlLower.includes("bsky.app") || urlLower.includes("bluesky")) {
    return { platform: "bluesky", url };
  }
  if (urlLower.includes("twitter.com") || urlLower.includes("x.com")) {
    return { platform: "twitter", url };
  }
  if (urlLower.includes("patreon.com")) {
    return { platform: "patreon", url };
  }
  if (urlLower.includes("ko-fi.com")) {
    return { platform: "kofi", url };
  }
  if (urlLower.includes("buymeacoffee.com")) {
    return { platform: "buymeacoffee", url };
  }
  if (isMastodonInstance(urlLower)) {
    return { platform: "mastodon", url };
  }
  return null;
}
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function fetchLinktreeLinks(linktreeUrl) {
  const socialLinks = [];
  const seenPlatforms = /* @__PURE__ */ new Set();
  try {
    const response = await globalThis.fetch(linktreeUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
      },
      signal: AbortSignal.timeout(5e3)
    });
    if (!response.ok) {
      console.log("Linktree fetch failed:", response.status);
      return socialLinks;
    }
    const html = await response.text();
    const linkMatches = html.matchAll(/<a\s+[^>]*href=["']([^"']+)["'][^>]*>/gi);
    for (const match of linkMatches) {
      const url = match[1];
      if (!url.startsWith("http") || url.includes("linktr.ee")) continue;
      const socialLink = parseSocialUrl(url);
      if (socialLink && !seenPlatforms.has(socialLink.platform)) {
        seenPlatforms.add(socialLink.platform);
        socialLinks.push(socialLink);
      }
    }
    console.log(`[Linktree] Found ${socialLinks.length} social links from ${linktreeUrl}`);
  } catch (error) {
    const err = error;
    console.error("Linktree fetch error:", err.message);
  }
  return socialLinks;
}
function extractDiscogsArtistId(discogsUrl) {
  const match = discogsUrl.match(/\/artist\/(\d+)/);
  return match ? match[1] : null;
}
async function fetchDiscogsSocialLinks(discogsUrl) {
  const socialLinks = [];
  const artistId = extractDiscogsArtistId(discogsUrl);
  if (!artistId) return socialLinks;
  try {
    const response = await globalThis.fetch(`https://api.discogs.com/artists/${artistId}`, {
      headers: {
        "User-Agent": "Unstream/1.0 (https://unstream.stream - ethical music finder)"
      }
    });
    if (!response.ok) {
      console.log("Discogs API failed:", response.status);
      return socialLinks;
    }
    const data = await response.json();
    const urls = data.urls || [];
    for (const url of urls) {
      const socialLink = parseSocialUrl(url);
      if (socialLink) {
        socialLinks.push(socialLink);
      }
    }
  } catch (error) {
    const err = error;
    console.error("Discogs fetch error:", err.message);
  }
  return socialLinks;
}
async function fetchOfficialSiteSocialLinks(officialUrl) {
  const socialLinks = [];
  const seenPlatforms = /* @__PURE__ */ new Set();
  let linktreeUrl = null;
  try {
    const response = await globalThis.fetch(officialUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
      },
      signal: AbortSignal.timeout(5e3)
    });
    if (!response.ok) {
      console.log("Official site fetch failed:", response.status);
      return { socialLinks, linktreeUrl };
    }
    const html = await response.text();
    const fediverseMatch = html.match(/<meta\s+[^>]*property=["']fediverse:creator["'][^>]*content=["']([^"']+)["']/i) || html.match(/<meta\s+[^>]*content=["']([^"']+)["'][^>]*property=["']fediverse:creator["']/i);
    if (fediverseMatch) {
      const handle = fediverseMatch[1];
      const mastodonUrl = convertMastodonHandleToUrl(handle);
      if (mastodonUrl && !seenPlatforms.has("mastodon")) {
        seenPlatforms.add("mastodon");
        socialLinks.push({ platform: "mastodon", url: mastodonUrl });
      }
    }
    const relMeMatches = html.matchAll(/<(?:link|a)\s+[^>]*rel=["']me["'][^>]*href=["']([^"']+)["']/gi);
    for (const match of relMeMatches) {
      const url = match[1];
      if (url.startsWith("http") && isMastodonInstance(url.toLowerCase()) && !seenPlatforms.has("mastodon")) {
        seenPlatforms.add("mastodon");
        socialLinks.push({ platform: "mastodon", url });
        break;
      }
    }
    const hrefMatches = html.matchAll(/href=["']([^"']+)["']/gi);
    for (const match of hrefMatches) {
      const url = match[1];
      if (!url.startsWith("http")) continue;
      if (url.includes("linktr.ee") && !linktreeUrl) {
        linktreeUrl = url;
        console.log(`[Official Site] Found Linktree: ${linktreeUrl}`);
        continue;
      }
      const socialLink = parseSocialUrl(url);
      if (socialLink && !seenPlatforms.has(socialLink.platform)) {
        seenPlatforms.add(socialLink.platform);
        socialLinks.push(socialLink);
      }
    }
  } catch (error) {
    const err = error;
    console.error("Official site fetch error:", err.message);
  }
  return { socialLinks, linktreeUrl };
}
function mergeSocialLinks(...linkArrays) {
  const seenPlatforms = /* @__PURE__ */ new Set();
  const merged = [];
  for (const links of linkArrays) {
    for (const link of links) {
      if (!seenPlatforms.has(link.platform)) {
        seenPlatforms.add(link.platform);
        merged.push(link);
      }
    }
  }
  return merged;
}
async function searchMusicBrainz(query) {
  const emptyResult = {
    query,
    artistName: null,
    officialUrl: null,
    discogsUrl: null,
    hasPre2005Release: false,
    socialLinks: []
  };
  try {
    const searchUrl = `https://musicbrainz.org/ws/2/artist/?query=artist:${encodeURIComponent(query)}&fmt=json&limit=1`;
    const response = await globalThis.fetch(searchUrl, {
      headers: {
        "User-Agent": "Unstream/1.0 (https://github.com/unstream - ethical music finder)"
      }
    });
    if (!response.ok) {
      console.log("MusicBrainz artist search failed:", response.status);
      return emptyResult;
    }
    const data = await response.json();
    const artists = data.artists || [];
    if (artists.length === 0) return emptyResult;
    const artist = artists[0];
    if (artist.score < 95) return emptyResult;
    const queryNormalized = query.toLowerCase().replace(/[^a-z0-9]/g, "");
    const artistNormalized = artist.name.toLowerCase().replace(/[^a-z0-9]/g, "");
    const isNameMatch = queryNormalized === artistNormalized || queryNormalized.includes(artistNormalized) && artistNormalized.length > queryNormalized.length * 0.7 || artistNormalized.includes(queryNormalized) && queryNormalized.length > artistNormalized.length * 0.7;
    if (!isNameMatch) {
      console.log(`[MusicBrainz] Skipping "${artist.name}" - doesn't match query "${query}"`);
      return emptyResult;
    }
    await delay(1100);
    const artistUrl = `https://musicbrainz.org/ws/2/artist/${artist.id}?inc=url-rels&fmt=json`;
    const artistResponse = await globalThis.fetch(artistUrl, {
      headers: {
        "User-Agent": "Unstream/1.0 (https://github.com/unstream - ethical music finder)"
      }
    });
    let officialUrl = null;
    let discogsUrl = null;
    let linktreeUrl = null;
    const socialLinks = [];
    const seenPlatforms = /* @__PURE__ */ new Set();
    if (artistResponse.ok) {
      const artistData = await artistResponse.json();
      const relations = artistData.relations || [];
      for (const rel of relations) {
        if (rel.type === "official homepage" && rel.url?.resource) {
          officialUrl = rel.url.resource;
          break;
        }
      }
      for (const rel of relations) {
        if (rel.type === "discogs" && rel.url?.resource) {
          discogsUrl = rel.url.resource;
          break;
        }
      }
      for (const rel of relations) {
        if ((rel.type === "social network" || rel.type === "youtube") && rel.url?.resource) {
          const url = rel.url.resource;
          if (url.includes("linktr.ee") && !linktreeUrl) {
            linktreeUrl = url;
            console.log(`[MusicBrainz] Found Linktree: ${linktreeUrl}`);
            continue;
          }
          const socialLink = parseSocialUrl(url);
          if (socialLink && !seenPlatforms.has(socialLink.platform)) {
            seenPlatforms.add(socialLink.platform);
            socialLinks.push(socialLink);
          }
        }
      }
    }
    await delay(1100);
    const releasesUrl = `https://musicbrainz.org/ws/2/release-group/?artist=${artist.id}&fmt=json&limit=20`;
    const releasesResponse = await globalThis.fetch(releasesUrl, {
      headers: {
        "User-Agent": "Unstream/1.0 (https://github.com/unstream - ethical music finder)"
      }
    });
    let hasPre2005Release = false;
    if (releasesResponse.ok) {
      const releasesData = await releasesResponse.json();
      const releaseGroups = releasesData["release-groups"] || [];
      for (const rg of releaseGroups) {
        const firstReleaseDate = rg["first-release-date"];
        if (firstReleaseDate) {
          const year = parseInt(firstReleaseDate.substring(0, 4), 10);
          if (year < 2005) {
            hasPre2005Release = true;
            break;
          }
        }
      }
    }
    const [discogsSocialLinks, officialSiteResult] = await Promise.all([
      discogsUrl ? fetchDiscogsSocialLinks(discogsUrl) : Promise.resolve([]),
      officialUrl ? fetchOfficialSiteSocialLinks(officialUrl) : Promise.resolve({ socialLinks: [], linktreeUrl: null })
    ]);
    const finalLinktreeUrl = linktreeUrl || officialSiteResult.linktreeUrl;
    let linktreeSocialLinks = [];
    if (finalLinktreeUrl) {
      linktreeSocialLinks = await fetchLinktreeLinks(finalLinktreeUrl);
    }
    const allSocialLinks = mergeSocialLinks(socialLinks, discogsSocialLinks, officialSiteResult.socialLinks, linktreeSocialLinks);
    return {
      query,
      artistName: artist.name,
      officialUrl,
      discogsUrl,
      hasPre2005Release,
      socialLinks: allSocialLinks
    };
  } catch (error) {
    const err = error;
    console.error("MusicBrainz search error:", err.name, err.message);
    return emptyResult;
  }
}
async function handler(event) {
  const query = event.queryStringParameters?.query;
  if (!query) {
    return {
      statusCode: 400,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: "Query parameter is required" })
    };
  }
  try {
    const result = await searchMusicBrainz(query);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "s-maxage=300, stale-while-revalidate"
      },
      body: JSON.stringify(result)
    };
  } catch (error) {
    console.error("MusicBrainz endpoint error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        query,
        artistName: null,
        officialUrl: null,
        discogsUrl: null,
        hasPre2005Release: false,
        socialLinks: []
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
